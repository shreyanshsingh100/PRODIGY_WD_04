const apiKey = '7d5e74e7b112e34001dc87b79a2fc7c3'; // Replace with your OpenWeatherMap API key
const searchButton = document.getElementById('search-button');
const locationButton = document.getElementById('location-button'); // New location button
const cityInput = document.getElementById('city-input');
const weatherInfo = document.getElementById('weather-info');

searchButton.addEventListener('click', fetchWeather);
cityInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        fetchWeather(cityInput.value);
    }
});

// New event listener for location button
locationButton.addEventListener('click', getLocation);

function fetchWeather(city) {
  if (!city) {
        city = cityInput.value; 
    }
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error('City not found');
            }
            return response.json();
        })
        .then(data => displayWeather(data))
        .catch(error => {
            weatherInfo.innerHTML = `<p class="error">${error.message}</p>`;
        });
}

function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const { latitude, longitude } = position.coords;
                fetchWeatherByCoordinates(latitude, longitude);
            },
            () => {
                alert('Unable to retrieve your location.');
            }
        );
    } else {
        alert('Geolocation is not supported by this browser.');
    }
}

function fetchWeatherByCoordinates(lat, lon) {
    const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`;

    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error('Unable to fetch weather data');
            }
            return response.json();
        })
        .then(data => displayWeather(data))
        .catch(error => {
            weatherInfo.innerHTML = `<p class="error">${error.message}</p>`;
        });
}

function displayWeather(data) {
    const { name, main, weather } = data;
    const temperature = main.temp;
    const description = weather[0].description;
    const icon = `https://openweathermap.org/img/wn/${weather[0].icon}.png`;

    weatherInfo.innerHTML = `
        <h2>${name}</h2>
        <img src="${icon}" alt="${description}">
        <p>Temperature: ${temperature}°C</p>
        <p>Condition: ${description}</p>
    `;
}
